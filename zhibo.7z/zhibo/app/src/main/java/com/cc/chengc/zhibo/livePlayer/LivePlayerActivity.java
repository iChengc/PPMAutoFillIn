package com.cc.chengc.zhibo.livePlayer;

import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cc.chengc.zhibo.R;

import java.util.List;

/**
 * Created by ChengC on 2016/5/16.
 */
public class LivePlayerActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String VIDEO_PATH_KEY = "com.cc.chengc.zhibo.LivePlayer.LivePlayerActivity";
    private ImageButton mBackBtn;
    private TextView mTitleView;
    private VideoView mPlayerView;
    private View mBuffer;
    private RelativeLayout mPlayToolbar;

    private MediaController mMediaController;
    private String mVideoPath = null;
    private  boolean mPauseInBackground = true;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.live_player_layout);
        mVideoPath = getIntent().getStringExtra(VIDEO_PATH_KEY);
        initViews();
    }

    private void initViews() {
        mBackBtn = (ImageButton) findViewById(R.id.player_exit);
        mBackBtn.setOnClickListener(this);

        mTitleView = (TextView) findViewById(R.id.player_video_title);
        mTitleView.setText(getVideoTitle());

        mPlayToolbar = (RelativeLayout)findViewById(R.id.play_toolbar);
        mPlayToolbar.setVisibility(View.INVISIBLE);

        mBuffer = findViewById(R.id.buffering_prompt);
        mPlayerView = (VideoView) findViewById(R.id.live_player_view);
        initPlayerView();
    }
    private void initPlayerView() {
        mMediaController = new MediaController(this);
        mPlayerView.setBufferStrategy(0); //直播低延时
        mPlayerView.setMediaController(mMediaController);
        mPlayerView.setBufferPrompt(mBuffer);
        mPlayerView.setMediaType(VideoView.MEDIA_TYPE_LIVE);
        mPlayerView.setHardwareDecoder(true);
        mPlayerView.setPauseInBackground(mPauseInBackground);
        mPlayerView.setVideoPath(mVideoPath);
        mPlayerView.requestFocus();
        mPlayerView.start();

        mMediaController.setOnShownListener(new MediaController.OnShownListener() {
            @Override
            public void onShown() {
                mPlayToolbar.setVisibility(View.VISIBLE);
                mPlayToolbar.requestLayout();
                mPlayerView.invalidate();
                mPlayToolbar.postInvalidate();
            }
        });
        mMediaController.setOnHiddenListener(new MediaController.OnHiddenListener() {
            @Override
            public void onHidden() {
                mPlayToolbar.setVisibility(View.INVISIBLE);
            }
        });
    }

    private String getVideoTitle() {
        if (TextUtils.isEmpty(mVideoPath)) {
            return "";
        }
        Uri mUri = Uri.parse(mVideoPath);
        if (mUri != null) { //获取文件名，不包括地址
            List<String> paths = mUri.getPathSegments();
            String name = paths == null || paths.isEmpty() ? "null" : paths.get(paths.size() - 1);
            return name;
        }
        return "";
    }
    
    @Override
    public void onClick(View v) {
        if (v == mBackBtn) {
            mPlayerView.release_resource();
            finish();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mPauseInBackground && mPlayerView.isPlaying()) {
            mPlayerView.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPlayerView.isPaused()) {
            mPlayerView.start();
        }
    }
}

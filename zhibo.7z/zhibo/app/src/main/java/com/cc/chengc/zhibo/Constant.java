package com.cc.chengc.zhibo;

/**
 * Created by ChengC on 2016/5/16.
 */
public class Constant {
    public static final String VIDEO_STREAM_URL ="http://v1.live.126.net/live/97329600f07a4facb58757f9ced9b5e6.flv";
    public static final String VIDEO_PUSH_URL = "rtmp://p1.live.126.net/live/97329600f07a4facb58757f9ced9b5e6?wsSecret=b922063b71ffac0fd0d226a6348e4223&wsTime=1463451216";
}

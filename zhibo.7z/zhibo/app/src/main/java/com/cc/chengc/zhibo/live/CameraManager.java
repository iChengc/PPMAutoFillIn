package com.cc.chengc.zhibo.live;

import android.graphics.Camera;
import android.os.Looper;

import java.util.concurrent.Semaphore;

/**
 * Created by ChengCn on 5/17/2016.
 */
public class CameraManager {
    private static CameraManager mInstance;
    public static CameraManager getInstance() {
        if (mInstance == null) {
            mInstance = new CameraManager();
        }

        return mInstance;
    }
    public static final int CAMERA_POSITION_BACK = 0;
    public static final int CAMERA_POSITION_FRONT = 1;

    private Thread mCameraThread;
    private Looper mCameraLooper;
    private android.hardware.Camera mCamera;
    private int mCameraID = CAMERA_POSITION_BACK;//默认查询的是后置摄像头
    //查询Android摄像头支持的采样分辨率相关方法（1）
    public void openCamera() {
        final Semaphore lock = new Semaphore(0);
        final RuntimeException[] exception = new RuntimeException[1];
        mCameraThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                mCameraLooper = Looper.myLooper();
                try {
                    mCamera = android.hardware.Camera.open(mCameraID);
                } catch (RuntimeException e) {
                    exception[0] = e;
                } finally {
                    lock.release();
                    Looper.loop();
                }
            }
        });
        mCameraThread.start();
        lock.acquireUninterruptibly();
    }

    //查询Android摄像头支持的采样分辨率相关方法（2）
    public void lockCamera() {
        try {
            mCamera.reconnect();
        } catch (Exception e) {
        }
    }

    //查询Android摄像头支持的采样分辨率相关方法（3）
    public void releaseCamera() {
        if (mCamera != null) {
            lockCamera();
            mCamera.setPreviewCallback(null);
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }
    }
}

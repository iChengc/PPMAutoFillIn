package com.cc.chengc.zhibo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.cc.chengc.zhibo.live.LiveActivity;
import com.cc.chengc.zhibo.livePlayer.LivePlayerActivity;

public class MainActivity extends AppCompatActivity {
    private TextView mStartLiveBtn, mViewLiveBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mStartLiveBtn = (TextView) findViewById(R.id.start_live_btn);
        mStartLiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startLive();
            }
        });
        mViewLiveBtn = (TextView) findViewById(R.id.view_live_btn);
        mViewLiveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewLive();
            }
        });
    }

    private void startLive() {
        Intent i = new Intent(this, LiveActivity.class);
        i.putExtra(LiveActivity.LIVE_STREAM_URL_KEY, Constant.VIDEO_PUSH_URL);
        startActivity(i);
    }

    private void viewLive() {
        Intent i = new Intent(this, LivePlayerActivity.class);
        i.putExtra(LivePlayerActivity.VIDEO_PATH_KEY, Constant.VIDEO_STREAM_URL);
        startActivity(i);
    }
}

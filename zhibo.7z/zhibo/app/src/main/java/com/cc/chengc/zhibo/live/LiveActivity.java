package com.cc.chengc.zhibo.live;

import android.content.Intent;
import android.media.AudioFormat;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;

import com.cc.chengc.zhibo.R;
import com.netease.LSMediaCapture.lsMediaCapture;
import com.netease.LSMediaCapture.lsMessageHandler;
import com.netease.livestreamingFilter.view.CameraSurfaceView;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class LiveActivity extends AppCompatActivity implements lsMessageHandler {
    public static final String LIVE_STREAM_URL_KEY = "com.cc.chengc.zhibo.live.LIVE_STREAM_URL_KEY";

    public static final int VIDEO_RESOLUTION_HD = 0;
    public static final int VIDEO_RESOLUTION_SD = 1;
    public static final int VIDEO_RESOLUTION_LD = 2;

    public static final int CAMERA_POSITION_BACK = 0;
    public static final int CAMERA_POSITION_FRONT = 1;

    public static final int CAMERA_ORIENTATION_PORTRAIT = 0;
    public static final int CAMERA_ORIENTATION_LANDSCAPE = 1;

    public static final int LS_VIDEO_CODEC_AVC = 0;
    public static final int LS_VIDEO_CODEC_VP9 = 1;
    public static final int LS_VIDEO_CODEC_H265 = 2;

    public static final int LS_AUDIO_STREAMING_LOW_QUALITY = 0;
    public static final int LS_AUDIO_STREAMING_HIGH_QUALITY = 1;

    public static final int LS_AUDIO_CODEC_AAC = 0;
    public static final int LS_AUDIO_CODEC_SPEEX = 1;
    public static final int LS_AUDIO_CODEC_MP3 = 2;
    public static final int LS_AUDIO_CODEC_G711A = 3;
    public static final int LS_AUDIO_CODEC_G711U = 4;

    public static final int FLV = 0;
    public static final int RTMP = 1;

    public static final int HAVE_AUDIO = 0;
    public static final int HAVE_VIDEO = 1;
    public static final int HAVE_AV = 2;

    private lsMediaCapture.LSLiveStreamingParaCtx mLSLiveStreamingParaCtx = null;
    private lsMediaCapture mLSMediaCapture = null;
    private String mliveStreamingURL = null;
    private ImageButton startPauseResumeBtn;
    private CameraSurfaceView mCameraSurfaceView;

    private ImageButton switchBtn;

    private boolean m_liveStreamingOn = false;
    private boolean m_liveStreamingInit = false;
    private boolean m_liveStreamingInitFinished = false;
    private boolean m_tryToStopLivestreaming = false;
    private boolean m_QoSToStopLivestreaming = false;
    private boolean m_startVideoCamera = false;

    private int mVideoResolution = VIDEO_RESOLUTION_SD, mVideoPreviewWidth, mVideoPreviewHeight;

    private float mCurrentDistance;
    private float mLastDistance = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);   //应用运行时，保持屏幕高亮，不锁屏
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live);

        init();
    }

    @Override
    protected void onDestroy() {
        if(m_liveStreamingInit) {
            m_liveStreamingInit = false;
        }

        //停止直播调用相关API接口
        if(mLSMediaCapture != null && m_startVideoCamera && m_liveStreamingOn) {
            mLSMediaCapture.stopLiveStreaming();
            mLSMediaCapture.stopVideoPreview();
            mLSMediaCapture.destroyVideoPreview();
            mLSMediaCapture = null;
        }
        else if(mLSMediaCapture != null && m_startVideoCamera)
        {
            mLSMediaCapture.stopVideoPreview();
            mLSMediaCapture.destroyVideoPreview();
            mLSMediaCapture = null;

        }

        if(m_liveStreamingOn) {
            m_liveStreamingOn = false;
        }

        super.onDestroy();
    }

    protected void onPause(){
        if(mLSMediaCapture != null) {
            if(!m_tryToStopLivestreaming && m_liveStreamingOn)
            {
                //继续视频推流，推固定图像
                mLSMediaCapture.resumeVideoEncode();

                //释放音频采集资源
                //mLSMediaCapture.stopAudioRecord();
            }
        }
        super.onPause();
    }

    protected void onRestart(){
        if(mLSMediaCapture != null) {
            //关闭推流固定图像
            mLSMediaCapture.stopVideoEncode();

            //关闭推流静音帧
            //mLSMediaCapture.stopAudioEncode();
        }
        super.onRestart();
    }


    private void init() {
        initViews();
        resetResolutionSize();

        mliveStreamingURL = getIntent().getStringExtra(LIVE_STREAM_URL_KEY);

        mLSMediaCapture = new lsMediaCapture(this, this, mVideoPreviewWidth, mVideoPreviewHeight);
        paraSet();
        mCameraSurfaceView.setPreviewSize(mVideoPreviewWidth, mVideoPreviewHeight);
        mLSMediaCapture.startVideoPreviewOpenGL(mCameraSurfaceView, mLSLiveStreamingParaCtx.sLSVideoParaCtx.cameraPosition.cameraPosition);
        m_startVideoCamera = true;

        //6、初始化直播推流
        boolean ret = mLSMediaCapture.initLiveStream(mliveStreamingURL, mLSLiveStreamingParaCtx);

        if (ret) {
            m_liveStreamingInit = true;
            m_liveStreamingInitFinished = true;
        } else {
            m_liveStreamingInit = true;
            m_liveStreamingInitFinished = false;
        }
    }

    public void initViews() {

        //开始直播按钮初始化
        startPauseResumeBtn = (ImageButton) findViewById(R.id.StartStopAVBtn);
        startPauseResumeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!m_liveStreamingOn) {
                    if (TextUtils.isEmpty(mliveStreamingURL))
                        return;

                    startLive();

                    startPauseResumeBtn.setImageResource(R.drawable.pause);
                }
            }
        });

        //切换前后摄像头按钮初始化
        switchBtn = (ImageButton) findViewById(R.id.switchBtn);
        switchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchCamera();
            }
        });

        mCameraSurfaceView = (CameraSurfaceView) findViewById(R.id.camerasurfaceview);
    }
    //音视频参数设置
    public void paraSet(){

        //创建参数实例
        mLSLiveStreamingParaCtx = mLSMediaCapture.new LSLiveStreamingParaCtx();
        mLSLiveStreamingParaCtx.eHaraWareEncType = mLSLiveStreamingParaCtx.new HardWareEncEnable();
        mLSLiveStreamingParaCtx.eOutFormatType = mLSLiveStreamingParaCtx.new OutputFormatType();
        mLSLiveStreamingParaCtx.eOutStreamType = mLSLiveStreamingParaCtx.new OutputStreamType();
        mLSLiveStreamingParaCtx.sLSAudioParaCtx = mLSLiveStreamingParaCtx.new LSAudioParaCtx();
        mLSLiveStreamingParaCtx.sLSAudioParaCtx.codec = mLSLiveStreamingParaCtx.sLSAudioParaCtx.new LSAudioCodecType();
        mLSLiveStreamingParaCtx.sLSVideoParaCtx = mLSLiveStreamingParaCtx.new LSVideoParaCtx();
        mLSLiveStreamingParaCtx.sLSVideoParaCtx.codec = mLSLiveStreamingParaCtx.sLSVideoParaCtx.new LSVideoCodecType();
        mLSLiveStreamingParaCtx.sLSVideoParaCtx.cameraPosition = mLSLiveStreamingParaCtx.sLSVideoParaCtx.new CameraPosition();
        mLSLiveStreamingParaCtx.sLSVideoParaCtx.interfaceOrientation = mLSLiveStreamingParaCtx.sLSVideoParaCtx.new CameraOrientation();



        //设置摄像头信息，并开始本地视频预览
        mLSLiveStreamingParaCtx.sLSVideoParaCtx.cameraPosition.cameraPosition = CAMERA_POSITION_BACK;//默认后置摄像头，用户可以根据需要调整

        //输出格式：视频、音频和音视频
        mLSLiveStreamingParaCtx.eOutStreamType.outputStreamType = HAVE_AV;

        //输出封装格式
        mLSLiveStreamingParaCtx.eOutFormatType.outputFormatType = RTMP;

        //摄像头参数配置
        mLSLiveStreamingParaCtx.sLSVideoParaCtx.interfaceOrientation.interfaceOrientation = CAMERA_ORIENTATION_PORTRAIT;//竖屏

        //音频编码参数配置
        mLSLiveStreamingParaCtx.sLSAudioParaCtx.samplerate = 44100;
        mLSLiveStreamingParaCtx.sLSAudioParaCtx.bitrate = 64000;
        mLSLiveStreamingParaCtx.sLSAudioParaCtx.frameSize = 2048;
        mLSLiveStreamingParaCtx.sLSAudioParaCtx.audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
        mLSLiveStreamingParaCtx.sLSAudioParaCtx.channelConfig = AudioFormat.CHANNEL_IN_MONO;
        mLSLiveStreamingParaCtx.sLSAudioParaCtx.codec.audioCODECType = LS_AUDIO_CODEC_AAC;

        //硬件编码参数设置
        mLSLiveStreamingParaCtx.eHaraWareEncType.hardWareEncEnable = true;

        //如下是编码分辨率等信息的设置
        if(mVideoResolution == VIDEO_RESOLUTION_HD) {
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.fps = 20;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.bitrate = 800000;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.codec.videoCODECType = LS_VIDEO_CODEC_AVC;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.width = 960;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.height = 540;
        }
        else if(mVideoResolution== VIDEO_RESOLUTION_SD) {
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.fps = 20;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.bitrate = 600000;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.codec.videoCODECType = LS_VIDEO_CODEC_AVC;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.width = 640;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.height = 480;
        }
        else {
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.fps = 15;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.bitrate = 250000;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.codec.videoCODECType = LS_VIDEO_CODEC_AVC;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.width = 320;
            mLSLiveStreamingParaCtx.sLSVideoParaCtx.height = 240;
        }
    }
    private void resetResolutionSize() {
        switch (mVideoResolution) {
            case VIDEO_RESOLUTION_HD:
                mVideoPreviewWidth = 960;
                mVideoPreviewHeight = 720;
                break;
            case VIDEO_RESOLUTION_SD:
                mVideoPreviewWidth = 640;
                mVideoPreviewHeight = 480;
                break;
            case VIDEO_RESOLUTION_LD:
                mVideoPreviewWidth = 320;
                mVideoPreviewHeight = 240;
                break;
        }
    }

    private void startLive() {
        if (mLSMediaCapture != null && m_liveStreamingInitFinished) {

            mLSMediaCapture.startLiveStreaming();
            m_liveStreamingOn = true;
        }
    }

    private void switchCamera() {
        if (mLSMediaCapture != null) {
            mLSMediaCapture.switchCamera();
        }
    }

    @Override
    public void handleMessage(int msg, Object obj) {
        switch (msg) {
            case MSG_INIT_LIVESTREAMING_OUTFILE_ERROR://初始化直播出错
            case MSG_INIT_LIVESTREAMING_VIDEO_ERROR:
            case MSG_INIT_LIVESTREAMING_AUDIO_ERROR: {
               /* if(m_liveStreamingInit)
                {
                    Bundle bundle = new Bundle();
                    bundle.putString("alert", "MSG_INIT_LIVESTREAMING_ERROR");
                    Intent intent = new Intent(MediaPreviewActivity.this, AlertService.class);
                    intent.putExtras(bundle);
                    startService(intent);
                    mAlertServiceOn = true;
                }*/
                break;
            }
            case MSG_START_LIVESTREAMING_ERROR://开始直播出错
            {
                break;
            }
            case MSG_STOP_LIVESTREAMING_ERROR://停止直播出错
            {
                /*if(m_liveStreamingOn)
                {
                    Bundle bundle = new Bundle();
                    bundle.putString("alert", "MSG_STOP_LIVESTREAMING_ERROR");
                    Intent intent = new Intent(MediaPreviewActivity.this, AlertService.class);
                    intent.putExtras(bundle);
                    startService(intent);
                    mAlertServiceOn = true;
                }*/
                break;
            }
            case MSG_AUDIO_PROCESS_ERROR://音频处理出错
            {
                /*if(m_liveStreamingOn && System.currentTimeMillis() - mLastAudioProcessErrorAlertTime >= 10000)
                {
                    Bundle bundle = new Bundle();
                    bundle.putString("alert", "MSG_AUDIO_PROCESS_ERROR");
                    Intent intent = new Intent(MediaPreviewActivity.this, AlertService.class);
                    intent.putExtras(bundle);
                    startService(intent);
                    mAlertServiceOn = true;
                    mLastAudioProcessErrorAlertTime = System.currentTimeMillis();
                }*/

                break;
            }
            case MSG_VIDEO_PROCESS_ERROR://视频处理出错
            {
                /*if(m_liveStreamingOn && System.currentTimeMillis() - mLastVideoProcessErrorAlertTime >= 10000)
                {
                    Bundle bundle = new Bundle();
                    bundle.putString("alert", "MSG_VIDEO_PROCESS_ERROR");
                    Intent intent = new Intent(MediaPreviewActivity.this, AlertService.class);
                    intent.putExtras(bundle);
                    startService(intent);
                    mAlertServiceOn = true;
                    mLastVideoProcessErrorAlertTime = System.currentTimeMillis();
                }*/
                break;
            }
            case MSG_RTMP_URL_ERROR://断网消息
            {
                //Log.i(TAG, "test: in handleMessage, MSG_RTMP_URL_ERROR");

                break;
            }
            case MSG_URL_NOT_AUTH://直播URL非法
            {
                /*if(m_liveStreamingInit)
                {
                    Bundle bundle = new Bundle();
                    bundle.putString("alert", "MSG_URL_NOT_AUTH");
                    Intent intent = new Intent(MediaPreviewActivity.this, AlertService.class);
                    intent.putExtras(bundle);
                    startService(intent);
                    mAlertServiceOn = true;
                }*/
                break;
            }
            case MSG_SEND_STATICS_LOG_ERROR://发送统计信息出错
            {
                //Log.i(TAG, "test: in handleMessage, MSG_SEND_STATICS_LOG_ERROR");
                break;
            }
            case MSG_SEND_HEARTBEAT_LOG_ERROR://发送心跳信息出错
            {
                //Log.i(TAG, "test: in handleMessage, MSG_SEND_HEARTBEAT_LOG_ERROR");
                break;
            }
            case MSG_AUDIO_SAMPLE_RATE_NOT_SUPPORT_ERROR://音频采集参数不支持
            {
                //Log.i(TAG, "test: in handleMessage, MSG_AUDIO_SAMPLE_RATE_NOT_SUPPORT_ERROR");
                break;
            }
            case MSG_AUDIO_PARAMETER_NOT_SUPPORT_BY_HARDWARE_ERROR://音频参数不支持
            {
                //Log.i(TAG, "test: in handleMessage, MSG_AUDIO_PARAMETER_NOT_SUPPORT_BY_HARDWARE_ERROR");
                break;
            }
            case MSG_NEW_AUDIORECORD_INSTANCE_ERROR://音频实例初始化出错
            {
                //Log.i(TAG, "test: in handleMessage, MSG_NEW_AUDIORECORD_INSTANCE_ERROR");
                break;
            }
            case MSG_AUDIO_START_RECORDING_ERROR://音频采集出错
            {
                //Log.i(TAG, "test: in handleMessage, MSG_AUDIO_START_RECORDING_ERROR");
                break;
            }
            case MSG_OTHER_AUDIO_PROCESS_ERROR://音频操作的其他错误
            {
                //Log.i(TAG, "test: in handleMessage, MSG_OTHER_AUDIO_PROCESS_ERROR");
                break;
            }
            case MSG_QOS_TO_STOP_LIVESTREAMING://网络QoS极差，码率档次降到最低
            {
                //Log.i(TAG, "test: in handleMessage, MSG_QOS_TO_STOP_LIVESTREAMING");
//		    	  m_tryToStopLivestreaming = true;
//		    	  m_QoSToStopLivestreaming = true;
//		  		  mLSMediaCapture.stopLiveStreaming();

                break;
            }
            case MSG_HW_VIDEO_PACKET_ERROR: {
               /* if(m_liveStreamingOn)
                {
                    Bundle bundle = new Bundle();
                    bundle.putString("alert", "MSG_HW_VIDEO_PACKET_ERROR");
                    Intent intent = new Intent(MediaPreviewActivity.this, AlertService.class);
                    intent.putExtras(bundle);
                    startService(intent);
                    mAlertServiceOn = true;
                }*/
                break;
            }
            case MSG_WATERMARK_INIT_ERROR://视频水印操作初始化出错
            {
                break;
            }
            case MSG_WATERMARK_PIC_OUT_OF_VIDEO_ERROR://视频水印图像超出原始视频出错
            {
                //Log.i(TAG, "test: in handleMessage: MSG_WATERMARK_PIC_OUT_OF_VIDEO_ERROR");
                break;
            }
            case MSG_WATERMARK_PARA_ERROR://视频水印参数设置出错
            {
                //Log.i(TAG, "test: in handleMessage: MSG_WATERMARK_PARA_ERROR");
                break;
            }
            case MSG_CAMERA_PREVIEW_SIZE_NOT_SUPPORT_ERROR://camera采集分辨率不支持
            {
                //Log.i(TAG, "test: in handleMessage: MSG_CAMERA_PREVIEW_SIZE_NOT_SUPPORT_ERROR");
                break;
            }
            case MSG_START_PREVIEW_FINISHED://camera采集预览完成
            {
                break;
            }
            case MSG_START_LIVESTREAMING_FINISHED://开始直播完成
            {
                break;
            }
            case MSG_STOP_LIVESTREAMING_FINISHED://停止直播完成
            {
                //Log.i(TAG, "test: MSG_STOP_LIVESTREAMING_FINISHED");
                /*{
                    mIntentLiveStreamingStopFinished.putExtra("LiveStreamingStopFinished", 1);
                    sendBroadcast(mIntentLiveStreamingStopFinished);
                }*/

                break;
            }
            case MSG_STOP_VIDEO_CAPTURE_FINISHED: {
                //Log.i(TAG, "test: in handleMessage: MSG_STOP_VIDEO_CAPTURE_FINISHED");
                if (!m_tryToStopLivestreaming && mLSMediaCapture != null) {
                    //继续视频推流，推最后一帧图像
                    mLSMediaCapture.resumeVideoEncode();
                }
                break;
            }
            case MSG_STOP_RESUME_VIDEO_CAPTURE_FINISHED: {
                //Log.i(TAG, "test: in handleMessage: MSG_STOP_RESUME_VIDEO_CAPTURE_FINISHED");
                //开启视频preview
                if (mLSMediaCapture != null) {
                    mLSMediaCapture.resumeVideoPreview();
                    m_liveStreamingOn = true;
                    //开启视频推流，推正常帧
                    mLSMediaCapture.startVideoLiveStream();
                }
                break;
            }
            case MSG_STOP_AUDIO_CAPTURE_FINISHED: {
                //Log.i(TAG, "test: in handleMessage: MSG_STOP_AUDIO_CAPTURE_FINISHED");
                if (!m_tryToStopLivestreaming && mLSMediaCapture != null) {
                    //继续音频推流，推静音帧
                    mLSMediaCapture.resumeAudioEncode();
                }
                break;
            }
            case MSG_STOP_RESUME_AUDIO_CAPTURE_FINISHED: {
                //Log.i(TAG, "test: in handleMessage: MSG_STOP_RESUME_AUDIO_CAPTURE_FINISHED");
                //开启音频推流，推正常帧
                mLSMediaCapture.startAudioLiveStream();
                break;
            }
            case MSG_SWITCH_CAMERA_FINISHED://切换摄像头完成
            {
                int cameraId = (Integer) obj;//切换之后的camera id
                break;
            }
            case MSG_SEND_STATICS_LOG_FINISHED://发送统计信息完成
            {
                //Log.i(TAG, "test: in handleMessage, MSG_SEND_STATICS_LOG_FINISHED");
                break;
            }
            case MSG_SERVER_COMMAND_STOP_LIVESTREAMING: {
                //Log.i(TAG, "test: in handleMessage, MSG_SERVER_COMMAND_STOP_LIVESTREAMING");
                break;
            }
            case MSG_GET_STATICS_INFO: {
               /* Message message = new Message();
                mStatistics = (lsMediaCapture.Statistics) object;

                Bundle bundle = new Bundle();
                bundle.putInt("FR", mStatistics.videoSendFrameRate);
                bundle.putInt("VBR", mStatistics.videoSendBitRate);
                bundle.putInt("ABR", mStatistics.audioSendBitRate);
                bundle.putInt("TBR", mStatistics.totalRealSendBitRate);
                message.setData(bundle);

                mHandler.sendMessage(message);*/
                break;
            }
            case MSG_BAD_NETWORK_DETECT: {
                //Log.i(TAG, "test: in handleMessage, MSG_BAD_NETWORK_DETECT");

                m_tryToStopLivestreaming = true;
                m_QoSToStopLivestreaming = true;
                mLSMediaCapture.stopLiveStreaming();
                break;
            }
            case MSG_SCREENSHOT_FINISHED: {
                //Log.i(TAG, "test: in handleMessage, MSG_SCREENSHOT_FINISHED, buffer is " + (byte[]) object);

                getScreenShotByteBuffer((byte[]) obj);

                break;
            }
        }
    }

    //获取截屏图像的数据
    public void getScreenShotByteBuffer(byte[] screenShotByteBuffer) {
        FileOutputStream outStream = null;
        String mScreenShotFilePath = "/sdcard/test.jpg";
        if (mScreenShotFilePath != null) {
            try {
                if (mScreenShotFilePath != null) {

                    outStream = new FileOutputStream(String.format(mScreenShotFilePath));
                    outStream.write(screenShotByteBuffer);
                    outStream.close();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {

            }
        }
    }


    //Demo层视频缩放操作相关方法
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                //Log.i(TAG, "test: down!!!");
                break;
            case MotionEvent.ACTION_MOVE:
                //Log.i(TAG, "test: move!!!");
                /**
                 * 首先判断按下手指的个数是不是大于两个。
                 * 如果大于两个则执行以下操作（即图片的缩放操作）。
                 */
                if (event.getPointerCount() >= 2) {

                    float offsetX = event.getX(0) - event.getX(1);
                    float offsetY = event.getY(0) - event.getY(1);
                    /**
                     * 原点和滑动后点的距离差
                     */
                    mCurrentDistance = (float) Math.sqrt(offsetX * offsetX + offsetY * offsetY);
                    if (mLastDistance < 0) {
                        mLastDistance = mCurrentDistance;
                    } else {
                        /**
                         * 如果当前滑动的距离（currentDistance）比最后一次记录的距离（lastDistance）相比大于5英寸（也可以为其他尺寸），
                         * 那么现实图片放大
                         */
                        if (mCurrentDistance - mLastDistance > 5) {
                            //Log.i(TAG, "test: 放大！！！");
                            if (mLSMediaCapture != null) {
                                mLSMediaCapture.setCameraZoomPara(true);
                            }

                            mLastDistance = mCurrentDistance;
                            /**
                             * 如果最后的一次记录的距离（lastDistance）与当前的滑动距离（currentDistance）相比小于5英寸，
                             * 那么图片缩小。
                             */
                        } else if (mLastDistance - mCurrentDistance > 5) {
                            //Log.i(TAG, "test: 缩小！！！");
                            if (mLSMediaCapture != null) {
                                mLSMediaCapture.setCameraZoomPara(false);
                            }

                            mLastDistance = mCurrentDistance;
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                //Log.i(TAG, "test: up!!!");
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        m_tryToStopLivestreaming = true;
    }
}
